import cv2
import numpy as np
import face_recognition

imgAlok = face_recognition.load_image_file('image/alok.jpg')
imgAlok = cv2.cvtColor(imgAlok,cv2.COLOR_BGR2RGB)
imgTest = face_recognition.load_image_file('image/test.jpg')
imgTest = cv2.cvtColor(imgTest,cv2.COLOR_BGR2RGB)

faceloc = face_recognition.face_locations(imgAlok)[0]
encodeAlok = face_recognition.face_encodings(imgAlok)[0]
cv2.rectangle(imgAlok,(faceloc[3],faceloc[0]),(faceloc[1],faceloc[2]),(255,0,255),2)
# print(faceloc)
facelocTest = face_recognition.face_locations(imgTest)[0]
encodeTest = face_recognition.face_encodings(imgTest)[0]
cv2.rectangle(imgTest,(facelocTest[3],facelocTest[0]),(facelocTest[1],facelocTest[2]),(255,0,255),2)

results = face_recognition.compare_faces([encodeAlok],encodeTest)
faceDis = face_recognition.face_distance([encodeAlok],encodeTest)
print(results,faceDis)
cv2.putText(imgTest,f'{results} {round(faceDis[0],2)}',(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255),2)

cv2.imshow('Alok Gautam',imgAlok)
cv2.imshow('Alok Test',imgTest)
cv2.waitKey(0)